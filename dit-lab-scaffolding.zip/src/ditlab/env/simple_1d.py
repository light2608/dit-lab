"""A simple 1D environment implementation.

This environment models a linear world where the agent can move along a
discrete line of a fixed length. It tracks the agent's position and
optionally the position of a threat or other entities. It is designed
primarily for demonstration and testing purposes.
"""

from dataclasses import dataclass
from typing import Any, Dict

from .base import BaseEnvironment, EnvironmentState


@dataclass
class Simple1DState(EnvironmentState):
    """Extends the base state with a threat position and world size."""

    size: int = 10
    threat_position: int = 5
    light_level: float = 1.0
    noise_level: float = 0.0

    def to_dict(self) -> Dict[str, Any]:  # noqa: D401
        """Return a serialisable representation of the state."""
        return {
            "time_step": self.time_step,
            "agent_position": self.agent_position,
            "threat_position": self.threat_position,
            "size": self.size,
            "light_level": self.light_level,
            "noise_level": self.noise_level,
        }


class Simple1DEnvironment(BaseEnvironment):
    """Concrete implementation of a simple one‑dimensional world."""

    def __init__(self, size: int = 10) -> None:
        super().__init__()
        self.state = Simple1DState(size=size)

    def reset(self) -> EnvironmentState:
        """Reset the environment to its initial state."""
        self.state = Simple1DState(size=self.state.size)
        return self.state

    def step(self, action: Any) -> EnvironmentState:
        """Move the agent according to the action and update time step.

        The action is expected to be one of {"left", "right", "stay"}.

        Args:
            action: The action taken by the agent.

        Returns:
            The updated environment state.
        """
        # Basic movement logic
        if isinstance(action, str):
            if action.lower() == "left":
                self.state.agent_position = max(0, self.state.agent_position - 1)
            elif action.lower() == "right":
                self.state.agent_position = min(
                    self.state.size - 1, self.state.agent_position + 1
                )
            elif action.lower() == "stay":
                pass
        # Increment time step
        self.state.time_step += 1
        return self.state

    def inject_noise(self, intensity: float) -> None:
        """Add noise to the light level and noise level.

        Args:
            intensity: A float describing the noise intensity.
        """
        # For demonstration, adjust noise level linearly
        self.state.noise_level = max(0.0, min(1.0, self.state.noise_level + intensity))
        # Light level could also be perturbed
        return