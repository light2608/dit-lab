"""Environment subpackage.

This package contains various environment implementations for the DIT Lab.
Environments define the external world in which the agent operates. They
must expose a common interface defined by `BaseEnvironment` so the rest
of the system can interact with them generically.
"""

from .base import BaseEnvironment, EnvironmentState  # noqa: F401
from .simple_1d import Simple1DEnvironment  # noqa: F401
from .simple_2d import Simple2DEnvironment  # noqa: F401

__all__ = ["BaseEnvironment", "EnvironmentState", "Simple1DEnvironment", "Simple2DEnvironment"]