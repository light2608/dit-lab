"""Base classes and data structures for environments.

All environment implementations in DIT Lab should inherit from
``BaseEnvironment`` and override its methods to update the world state,
handle agent actions, and provide observations. The base environment
operates on a simple ``EnvironmentState`` dataclass to hold the minimal
information about the world.
"""

from dataclasses import dataclass, asdict
from typing import Any, Dict


@dataclass
class EnvironmentState:
    """Represents the minimal state of an environment.

    Subclasses may extend this dataclass with additional fields but
    should preserve the base behaviour of serialising to/from dicts.
    """

    time_step: int = 0
    agent_position: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Return a serialisable representation of the state."""
        return asdict(self)


class BaseEnvironment:
    """Abstract base class for all environments.

    Concrete subclasses must override the :meth:`reset` and :meth:`step`
    methods. Optionally, they may override :meth:`inject_noise` to alter
    the environment state between steps, for example to simulate sensor
    noise or environmental events.
    """

    def __init__(self) -> None:
        self.state = EnvironmentState()

    def reset(self) -> EnvironmentState:
        """Reset the environment to its initial state.

        Returns:
            The initial environment state.
        """
        self.state = EnvironmentState()
        return self.state

    def step(self, action: Any) -> EnvironmentState:
        """Advance the environment by one time step.

        Args:
            action: The action taken by the agent.

        Returns:
            The updated environment state.
        """
        raise NotImplementedError("Subclasses must implement step().")

    def inject_noise(self, intensity: float) -> None:
        """Optionally modify the environment state by adding noise.

        Args:
            intensity: A float describing the noise intensity.
        """
        # Default implementation does nothing.
        return