"""A simple 2D environment implementation.

This environment models a rectangular grid world where the agent can
move in four cardinal directions or stay in place. It extends the
base environment with x and y coordinates, world dimensions, and an
optional threat position. It is designed for experimentation with
two‑dimensional navigation and sensor noise.
"""

from dataclasses import dataclass
from typing import Any, Dict

from .base import BaseEnvironment, EnvironmentState


@dataclass
class Simple2DState(EnvironmentState):
    """Extends the base state with 2D positions and world size."""

    x_position: int = 0
    y_position: int = 0
    width: int = 10
    height: int = 10
    threat_x: int = 5
    threat_y: int = 5
    light_level: float = 1.0
    noise_level: float = 0.0

    def to_dict(self) -> Dict[str, Any]:  # noqa: D401
        """Return a serialisable representation of the state."""
        return {
            "time_step": self.time_step,
            "agent_position": (self.x_position, self.y_position),
            "threat_position": (self.threat_x, self.threat_y),
            "width": self.width,
            "height": self.height,
            "light_level": self.light_level,
            "noise_level": self.noise_level,
        }


class Simple2DEnvironment(BaseEnvironment):
    """Concrete implementation of a simple two‑dimensional world."""

    def __init__(self, width: int = 10, height: int = 10) -> None:
        super().__init__()
        self.state = Simple2DState(width=width, height=height)

    def reset(self) -> EnvironmentState:
        """Reset the environment to its initial state."""
        self.state = Simple2DState(width=self.state.width, height=self.state.height)
        return self.state

    def step(self, action: Any) -> EnvironmentState:
        """Move the agent according to the action and update time step.

        The action is expected to be one of {"left", "right", "up", "down", "stay"}.

        Args:
            action: The action taken by the agent.

        Returns:
            The updated environment state.
        """
        if isinstance(action, str):
            a = action.lower()
            if a == "left":
                self.state.x_position = max(0, self.state.x_position - 1)
            elif a == "right":
                self.state.x_position = min(self.state.width - 1, self.state.x_position + 1)
            elif a == "up":
                self.state.y_position = max(0, self.state.y_position - 1)
            elif a == "down":
                self.state.y_position = min(self.state.height - 1, self.state.y_position + 1)
            elif a == "stay":
                pass  # no movement
        # Increment time step
        self.state.time_step += 1
        return self.state

    def inject_noise(self, intensity: float) -> None:
        """Add noise to the light level and noise level.

        Args:
            intensity: A float describing the noise intensity.
        """
        self.state.noise_level = max(0.0, min(1.0, self.state.noise_level + intensity))
        return